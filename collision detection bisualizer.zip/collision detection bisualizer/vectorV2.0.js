//all angles will be in radian and angle inputs should also be in radian
class vector{
	constructor(x= 1, y= 0)
	{
		this.dx= x;
		this.dy= y;
	}
	
	get_angle= () => Math.atan2(this.dy, this.dx);

	get_mag= () => Math.sqrt(this.dx * this.dx + this.dy * this.dy);

	set_angle= angle => {
		//old method. still works
		var mag= this.get_mag();
		this.dx= Math.cos(angle) * mag;
		this.dy= Math.sin(angle) * mag;

		//new method
		//this.dx= (Math.cos(angle) * this.dx) - (Math.sin(angle) * this.dy);
		//this.dy= (Math.sin(angle) * this.dx) + (Math.cos(angle) * this.dy);
	}
	
	set_mag= new_mag => {
		//old method. still works.
		var angle= this.get_angle();
		this.dx= Math.cos(angle) * new_mag;
		this.dy= Math.sin(angle) * new_mag;	

		//new method
		//squaring new_mag to avoid using squrt to get vector magnitude
		/*let ratio= (this.dx * this.dx + this.dy * this.dy) / (new_mag * new_mag);	 
		this.dx = this.dx * ratio;
		this.dy = this.dy * ratio;*/
	}

	set_vect= vect => {
		this.dx= vect.dx;
		this.dy= vect.dy;
	}

	get_point= () => {
		return {dx: this.dx, dy: this.dy};
	};

	add= vect => {
		this.dx= this.dx + vect.dx; 
		this.dy= this.dy + vect.dy;
	}
		
	subtract= vect => {
		this.dx= this.dx - vect.dx; 
		this.dy= this.dy - vect.dy;	
	}
	
	multiply= scalar => {
		this.dx= this.dx * scalar;
		this.dy= this.dy * scalar;
	}

	divide= scalar => {
		this.dx= this.dx / scalar;
		this.dy= this.dy / scalar;
	}

	add2= (vect1, vect2) => new vector(vect1.dx + vect2.dx, vect1.dy + vect2.dy);

	subtract2= (vect1, vect2) => new vector(vect1.dx - vect2.dx, vect1.dy - vect2.dy);

	multply2= (vect, scalar) => new vector(vect.dx * scalar, vect.dy * scalar);

	divide2= (vect, scalar) => new vector(vect.dx / scalar, vect.dy / scalar);

	normalize= () => this.divide(this.get_mag());

	dot_product= vect => this.dx * vect.dx + this.dy * vect.dy;
}