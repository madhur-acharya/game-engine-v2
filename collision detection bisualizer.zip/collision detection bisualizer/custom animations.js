//This is where all the main animations are created

//here is a basic animation of colored balls moving across the screen
function explosions()
{
	for(var i= 0; i < balls.length; i++)
	{
		context.beginPath();
		context.fillStyle= balls[i].color;
		context.arc(balls[i].position.dx, balls[i].position.dy, balls[i].radius, 0, Math.PI * 2);
		balls[i].update_pos();
		context.fill();
		balls[i].radius= balls[i].radius + 0.25;
		balls[i].velocity.set_angle(balls[i].position.get_angle() - Math.PI / 6);
	}
	
	for(var i= 0; i < balls.length; i++)
	{ 
		if((balls[i].position.dx >= width / 2 + balls[i].radius || balls[i].position.dx <= -width / 2 - balls[i].radius) || (balls[i].position.dy >= height / 2 + balls[i].radius || balls[i].position.dy <= -height / 2 - balls[i].radius))
		{
			balls[i].position.set_dxy(0, 0);
			balls[i].color= getRandomColor();
			balls[i].radius= 1;
			balls[i].velocity.set_mag(Math.random() * 2 + 1.5);
		}
	}
}

function bouncing_balls(ball_1, ball_2)
{
	context.beginPath();
	context.fillStyle= ball_1.color;
	context.arc(ball_1.position.dx, ball_1.position.dy, 50, 0, Math.PI * 2);
	context.fill();
	context.beginPath();
	context.fillStyle= ball_2.color;
	context.arc(ball_2.position.dx, ball_2.position.dy, 50, 0, Math.PI * 2);
	context.fill();

	context.beginPath();
	context.lineWidth= 1;
	context.strokeStyle= "yellow";
	context.moveTo(ball_1.position.dx, ball_1.position.dy);
	context.lineTo(ball_2.position.dx, ball_2.position.dy);
	context.stroke();

	ball_1.update_pos();
	ball_2.update_pos();

	draw_vector(ball_1.position, ball_1.velocity, "red");
	draw_vector(ball_2.position, ball_2.velocity, "red");

	let normal_vector= new vector(ball_2.position.dx- ball_1.position.dx, ball_2.position.dy - ball_1.position.dy);
    normal_vector.normalize();
    let tangent_vector= new vector(-normal_vector.dy, normal_vector.dx);
    
    let mid= midpoint(ball_1.position, ball_2.position);

    draw_vector(mid, normal_vector, "grey");
	draw_vector(mid, tangent_vector, "grey");

    let u1n= ball_1.velocity.dot_product(normal_vector);
    let u2n= ball_2.velocity.dot_product(normal_vector);

    let u1t= ball_1.velocity.dot_product(tangent_vector);
    let u2t= ball_2.velocity.dot_product(tangent_vector);

   	let v1n= (u1n * (ball_1.mass - ball_2.mass) + (2 * ball_2.mass * u2n)) / (ball_1.mass + ball_2.mass);
   	let v2n= (u2n * (ball_2.mass - ball_1.mass) + (2 * ball_1.mass * u1n)) / (ball_1.mass + ball_2.mass);

   	v1n= new vector(v1n * normal_vector.dx, v1n * normal_vector.dy);
   	v2n= new vector(v2n * normal_vector.dx, v2n * normal_vector.dy);
   	u1t= new vector(u1t * tangent_vector.dx, u1t * tangent_vector.dy);
   	u2t= new vector(u2t * tangent_vector.dx, u2t * tangent_vector.dy);

   	let v1= new vector(v1n.dx + u1t.dx, v1n.dy + u1t.dy);
   	let v2= new vector(v2n.dx + u2t.dx, v2n.dy + u2t.dy);

	draw_vector(ball_1.position, v1, "blue");
	draw_vector(ball_2.position, v2, "blue");

	if(check_b2b_collision(ball_1, ball_2) == true)
	{
		//let temp1= new vector(-ball_1.velocity.dx, -ball_1.velocity.dy);
		//let temp2= new vector(-ball_1.velocity.dx, -ball_2.velocity.dy);
		ball_1.velocity= v1;
		ball_2.velocity= v2;
	}

	if(ball_1.position.dx >= width / 2 - ball_1.radius)
	{
		ball_1.position.dx= (width / 2) - ball_1.radius;
		ball_1.velocity.dx= -ball_1.velocity.dx;
	}
	else if(ball_1.position.dx <= -width / 2 + ball_1.radius)
	{
		ball_1.position.dx= -(width / 2) + ball_1.radius;
		ball_1.velocity.dx= -ball_1.velocity.dx;
	}
	
	if(ball_1.position.dy >= height / 2 - ball_1.radius)
	{
		ball_1.position.dy= (height / 2) - ball_1.radius;
		ball_1.velocity.dy= -ball_1.velocity.dy;
	}
	else if(ball_1.position.dy <= -height / 2 + ball_1.radius)
	{
		ball_1.position.dy= -(height / 2) + ball_1.radius;
		ball_1.velocity.dy= -ball_1.velocity.dy;
	}

	if(ball_2.position.dx >= width / 2 - ball_2.radius)
	{
		ball_2.position.dx= (width / 2) - ball_2.radius;
		ball_2.velocity.dx= -ball_2.velocity.dx;
	}
	else if(ball_2.position.dx <= -width / 2 + ball_2.radius)
	{
		ball_2.position.dx= -(width / 2) + ball_2.radius;
		ball_2.velocity.dx= -ball_2.velocity.dx;
	}
	
	if(ball_2.position.dy >= height / 2 - ball_2.radius)
	{
		ball_2.position.dy= (height / 2) - ball_2.radius;
		ball_2.velocity.dy= -ball_2.velocity.dy;
	}
	else if(ball_2.position.dy <= -height / 2 + ball_2.radius)
	{
		ball_2.position.dy= -(height / 2) + ball_2.radius;
		ball_2.velocity.dy= -ball_2.velocity.dy;
	}

}