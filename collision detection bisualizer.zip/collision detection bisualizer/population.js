//this is where all the particles and assets are stored.

var ball_array= [];
/*for(i= 0; i < 5; i ++)
{
	let bl= new particle(Math.floor(Math.random() * (width / 2)) - Math.floor(Math.random() * (width / 2)),
		Math.floor(Math.random() * (height / 2)) - Math.floor(Math.random() * (height / 2)), 
		Math.floor(Math.random() * 360) * Math.PI / 180, 
		Math.floor(Math.random() * 2));
	bl.color= getRandomColor();
	bl.mass= Math.floor(Math.random() * 50);
	bl.radius= 50;
	ball_array.push(bl);
}
console.log(ball_array);*/

var ball_1= new particle(-40, -200, 90 * Math.PI / 180, Math.floor(Math.random() * 10));
ball_1.mass= Math.floor(Math.random() * 50);
ball_1.radius= 50;
ball_1.color= getRandomColor();
ball_array.push(ball_1);
var ball_2= new particle(30, 200, -90 * Math.PI / 180, Math.floor(Math.random() * 10));
ball_2.mass= Math.floor(Math.random() * 50);
ball_2.radius= 50;
ball_2.color= getRandomColor();
ball_array.push(ball_2);
