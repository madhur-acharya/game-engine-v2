//this is where all the animations and methods are called. All animations should be called within the animate method

var delta= 0;
var bullet_delay= stopwatch();

function animate(timestamp)
{
	delta= calculate_framerate(timestamp);
	context.clearRect(-width / 2, -height / 2, width, height);

	for(i= 0; i < ball_array.length; i++)
	{
		for(j= 0; j < ball_array.length; j++)
		{
			if(ball_array[i] !== ball_array[j])
				bouncing_balls(ball_array[i], ball_array[j]);
		}
	}
	

	if(an_flag == false)
		ani_id= requestAnimationFrame(animate);
}