
function dist_between(p1, p2)
{
	return {dx: Math.abs(p1.dx - p2.dx), dy: Math.abs(p1.dy - p2.dy)};
};

function midpoint(p1, p2)
{
	return {dx : (p1.dx + p2.dx) / 2, dy: (p1.dy + p2.dy) / 2};
};
